# -*- coding: utf-8 -*-
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
#
# © 2025 Devansh (Author of TejOCR)

"""Constants used throughout the TejOCR extension."""

# --- Version Information ---
EXTENSION_VERSION = "0.2.2"
EXTENSION_NAME = "TejOCR"
EXTENSION_FULL_NAME = f"{EXTENSION_NAME} v{EXTENSION_VERSION}"

# --- Configuration Keys (for UNO ConfigurationProvider) ---
# Path: org.libreoffice.Office.Addons/TejOCR.Configuration/Settings
CFG_NODE_SETTINGS = "Settings"
CFG_KEY_TESSERACT_PATH = "TesseractPath"
CFG_KEY_DEFAULT_LANG = "DefaultOcrLanguage"
CFG_KEY_DEFAULT_OUTPUT_MODE = "default_output_mode"
CFG_KEY_DEFAULT_GRAYSCALE = "DefaultPreprocessingGrayscale"
CFG_KEY_DEFAULT_BINARIZE = "DefaultPreprocessingBinarize"
CFG_KEY_DEFAULT_INVERT = "DefaultPreprocessingInvert"
CFG_KEY_DEFAULT_PSM = "DefaultPSM"
CFG_KEY_DEFAULT_OEM = "DefaultOEM"
CFG_KEY_DEFAULT_PRESET = "DefaultQualityPreset"
CFG_KEY_IMPROVE_IMAGE_DEFAULT = "DefaultImproveImageQuality" # For image enhancement options
CFG_KEY_LAST_SELECTED_LANG = "LastSelectedOcrLanguage" # For OCR Options Dialog
CFG_KEY_LAST_OUTPUT_MODE = "LastOutputMode" # For OCR Options Dialog
CFG_KEY_DEFAULT_SCALE = "DefaultScaleFactor"
CFG_KEY_SHOW_PREVIEW_BEFORE_OUTPUT = "ShowPreviewBeforeOutput" # For preview/edit before inserting OCR text
CFG_KEY_MERGE_BATCH_RESULTS = "MergeBatchResults"
CFG_KEY_HIDDEN_OCR_EXECUTOR = "HiddenOcrExecutor"
CFG_KEY_UI_LANGUAGE = "UiLanguage"

# --- Default Values ---
DEFAULT_OCR_LANGUAGE = "eng"  # Default to English
DEFAULT_UI_LANGUAGE = "auto"
TEXT_DOMAIN = "tejocr"
DEFAULT_PREPROC_GRAYSCALE = False
DEFAULT_PREPROC_BINARIZE = False
DEFAULT_PREPROC_INVERT = False
DEFAULT_IMPROVE_IMAGE = False # Default to no image enhancement
DEFAULT_PSM_MODE_UI = "3"
DEFAULT_OEM_MODE_UI = "3"
DEFAULT_SCALE_FACTOR = "1.0" # Default image upscale factor as string for UI persistence
DEFAULT_SHOW_PREVIEW_BEFORE_OUTPUT = "true" # Show OCR preview/edit dialog before final output
DEFAULT_MERGE_BATCH_RESULTS = "true"
DEFAULT_TESSERACT_PATH = "" # Empty, to trigger auto-detection or user input
DEFAULT_OCR_OUTPUT_FONT_SIZE_PT = 6.0
DEFAULT_TEXTBOX_FONT_SIZE_PT = DEFAULT_OCR_OUTPUT_FONT_SIZE_PT

# --- Tesseract PSM (Page Segmentation Modes) --- 
# (Value: Description for UI)
TESSERACT_PSM_MODES = {
    "0": "0: Orientation and script detection only. Diagnostic mode; no OCR text output.",
    "1": "1: Automatic page segmentation with OSD.",
    "2": "2: Automatic page segmentation, but no OSD, or OCR. Diagnostic mode; not implemented for text output.",
    "3": "3: Fully automatic page segmentation, but no OSD. (Default)",
    "4": "4: Assume a single column of text of variable sizes.",
    "5": "5: Assume a single uniform block of vertically aligned text.",
    "6": "6: Assume a single uniform block of text.",
    "7": "7: Treat the image as a single text line.",
    "8": "8: Treat the image as a single word.",
    "9": "9: Treat the image as a single word in a circle.",
    "10": "10: Treat the image as a single character.",
    "11": "11: Sparse text. Find as much text as possible in no particular order.",
    "12": "12: Sparse text with OSD.",
    "13": "13: Raw line. Treat the image as a single text line, bypassing hacks that are Tesseract-specific."
}
DEFAULT_PSM_MODE = "3"

# --- Quality presets ---
OCR_PRESET_FAST = "fast"
OCR_PRESET_BALANCED = "balanced"
OCR_PRESET_ACCURATE = "accurate"
OCR_PRESET_CUSTOM = "custom"
DEFAULT_OCR_PRESET = OCR_PRESET_BALANCED

OCR_QUALITY_PRESETS = {
    OCR_PRESET_FAST: {
        "label": "Fast",
        "description": "Single exact OCR pass with minimal preprocessing",
        "psm": "11",
        "oem": "3",
        "scale": "1.0",
        "grayscale": False,
        "binarize": False,
        "invert": False,
        "improve_image": False,
    },
    OCR_PRESET_BALANCED: {
        "label": "Balanced",
        "description": "Exact OCR pass plus one smart recovery if output is weak",
        "psm": "3",
        "oem": "3",
        "scale": "1.0",
        "grayscale": True,
        "binarize": False,
        "invert": False,
        "improve_image": False,
    },
    OCR_PRESET_ACCURATE: {
        "label": "Accuracy",
        "description": "Exact OCR pass plus one enhanced preprocessing recovery",
        "psm": "6",
        "oem": "3",
        "scale": "1.5",
        "grayscale": True,
        "binarize": True,
        "invert": False,
        "improve_image": True,
    },
}

OCR_PRESET_CHOICES = (OCR_PRESET_FAST, OCR_PRESET_BALANCED, OCR_PRESET_ACCURATE, OCR_PRESET_CUSTOM)

OCR_EXECUTOR_MODERN = "modern"
OCR_EXECUTOR_LEGACY = "legacy"
OCR_EXECUTOR_CHOICES = (OCR_EXECUTOR_MODERN, OCR_EXECUTOR_LEGACY)
DEFAULT_OCR_EXECUTOR = OCR_EXECUTOR_MODERN

# --- Tesseract OEM (OCR Engine Modes) --- 
# (Value: Description for UI)
TESSERACT_OEM_MODES = {
    "0": "0: Legacy engine only.",
    "1": "1: Neural nets LSTM engine only.",
    "2": "2: Legacy + LSTM engines.",
    "3": "3: Default, based on what is available."
}
DEFAULT_OEM_MODE = "3"

# --- Output Modes (for OCR Options Dialog) ---
# These can be simple strings, as their primary use is for programmatic logic
# and to be stored in config. UI labels will come from i18n strings.
OUTPUT_MODE_CURSOR = "at_cursor"
OUTPUT_MODE_TEXTBOX = "new_textbox"
OUTPUT_MODE_REPLACE = "replace_image"
OUTPUT_MODE_CLIPBOARD = "to_clipboard"
DEFAULT_OUTPUT_MODE = OUTPUT_MODE_CURSOR

# --- Image Formats ---
# Used for file dialog filters. Should be a semicolon-separated string of wildcards.
IMAGE_FILE_DIALOG_FILTER = "*.png;*.jpg;*.jpeg;*.tiff;*.tif;*.bmp;*.gif;*.webp"
PDF_FILE_DIALOG_FILTER = "*.pdf;*.PDF"
IMAGE_OR_PDF_DIALOG_FILTER = f"{IMAGE_FILE_DIALOG_FILTER};{PDF_FILE_DIALOG_FILTER}"

# List of wildcards for internal checks if needed, derived from the above string.
IMAGE_WILDCARDS = [f.strip() for f in IMAGE_FILE_DIALOG_FILTER.split(';') if f.strip()]

# MIME types corresponding to the above wildcards, for clipboard or other type checks.
# This mapping might need to be more robust or comprehensive based on specific needs.
IMAGE_MIMETYPES = {
    "*.png": "image/png",
    "*.jpg": "image/jpeg",
    "*.jpeg": "image/jpeg",
    "*.tiff": "image/tiff",
    "*.tif": "image/tiff",
    "*.bmp": "image/bmp",
    "*.gif": "image/gif",
    "*.webp": "image/webp"
}

# Fallback/general list of supported MIME types if direct mapping isn't used.
SUPPORTED_IMAGE_MIMETYPES_LIST = list(set(IMAGE_MIMETYPES.values()))

# Format for temporarily saving/converting images for Tesseract if needed.
TEMP_IMAGE_FORMAT_FOR_TESSERACT = "PNG" # PNG is lossless and widely supported.

# --- Deprecated / To be reviewed ---
# SUPPORTED_IMAGE_FORMATS_DIALOG_FILTER = "*.png;*.jpg;*.jpeg;*.tiff;*.tif;*.bmp;*.webp" # Replaced by IMAGE_FILE_DIALOG_FILTER
# SUPPORTED_IMAGE_MIMETYPES = ["image/png", "image/jpeg", "image/tiff", "image/bmp", "image/webp"] # Replaced by SUPPORTED_IMAGE_MIMETYPES_LIST
# TEMP_IMAGE_FORMAT = "PNG" # Replaced by TEMP_IMAGE_FORMAT_FOR_TESSERACT


# --- Logging ---
LOG_FILE_NAME = "tejocr.log"
# Consider making log level configurable in settings in the future

# --- UI Related ---
DIALOG_MODAL_DEPENDENT = 1 # For com.sun.star.awt.MessageBoxType & Dialog behavior 

# Current Log Level (can be overridden by user config if implemented)
# Possible values: "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"
# Keep this at ERROR in production mode to keep runtime logs minimal.
CURRENT_LOG_LEVEL = "ERROR"

# Set to True only when actively debugging issues.
ENABLE_CONSOLE_LOGGING = False

# --- Development Flags ---
# When True, bypasses certain checks for placeholder UI testing
# When False, enables real OCR functionality
DEVELOPMENT_MODE_STRICT_PLACEHOLDERS = False

# Default file for logging, relative to user's temp directory subfolder
LOG_FILENAME = "tejocr.log"

# --- DEBUG CONSTANT FOR TESTING UPDATES ---
DEBUG_CONSTANT_VERSION = "v2_constants_test" 
